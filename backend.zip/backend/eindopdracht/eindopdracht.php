<?php
  $title = "";
  $imageName = ""; 
  $hour = date('H'); 

  if($hour >= 00 && $hour <= 06){
    $title =  "Goede nacht! Het is " . date('H'.':' . 'i');
    $imageName = "images/night.png";
  }
  else if($hour >= 06 && $hour <= 12){
    $title =  "Goedemorgen! Het is " . date('H'.':' . 'i');
    $imageName = "images/morning.png";
  }
  else if($hour >= 12 && $hour <= 18){
    $title =  "Goedemiddag! Het is " . date('H'.':' . 'i');
    $imageName = "images/afternoon.png";
  }
  else {
    $title =  "Goede avond! Het is" . date('H'.':' . 'i');
    $imageName = "images/evening.png";
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome</title>

  <style>
    body {
      margin: 0;
      padding: 0;
      width: 100%;
      background: url('<?=$imageName;?>') no-repeat center center fixed;
      background-size: cover;
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
    }
    h2{
      background: #fff;
      width: 300px;
      font-size: 30px;
      text-align: center;
      margin: 250px auto;
      padding: 10px 20px;
      border-radius: 5px;
    }
  </style>

</head>
<body>

<h2>
  <?=$title;?>
</h2>

</body>
</html>

