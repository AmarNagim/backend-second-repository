<?php
    
    $txt1 = "Hello World!";
    echo $txt1


?>