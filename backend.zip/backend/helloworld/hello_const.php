<?php
define("helloworld", "Hello World");
echo helloworld;
?>