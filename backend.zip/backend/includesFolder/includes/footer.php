<body>
    <div class='container'>
        <footer>Amar &copy; 2023</footer>
    </div>
</body>
<style>

    * {
        padding: 0;
        margin: 0;
        font-family: Arial, Helvetica, sans-serif;
    }

    .container {
        height: 60px;
        background-color: gray;
        display: flex;
        align-items: center;
        justify-content: center;

    }


</style>